package member;

public class memberDTO {

}
