package member;

public class MemberDAO {

}
