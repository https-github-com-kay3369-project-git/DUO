package aticleBoard;

public class aticleBoardDTO {

}
