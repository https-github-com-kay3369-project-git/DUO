package aticleBoard;

public class aticleBaordDAO {

}
