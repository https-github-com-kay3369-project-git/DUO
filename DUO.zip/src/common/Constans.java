package common;

public class Constans {
	public static final String 	UPOAD_PATH="c:/mvnupload/"; //파일 업로드할 폴더 설정
	public static final int MAX_UPLOAD=1024*1024*10; //파일업로드 최대 용량(10MB)
	
}
