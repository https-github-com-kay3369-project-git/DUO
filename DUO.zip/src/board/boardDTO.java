package board;

public class boardDTO {

}
